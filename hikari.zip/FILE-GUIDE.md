# Complete File Guide - Snowflake Hibernate/JPA Setup

## 📂 File Organization

```
your-project/
├── src/main/java/com/jpmorgan/ct/
│   ├── config/
│   │   ├── SnowflakeHibernateConfiguration.java      ⭐ MAIN CONFIG
│   │   ├── SnowflakeDialect.java                     ⭐ HIBERNATE DIALECT
│   │   └── SnowflakeDbConfigProperties.java          📝 Properties
│   │
│   ├── model/
│   │   └── RlenMetadata.java                         📋 ENTITY EXAMPLE
│   │
│   ├── repository/
│   │   └── RlenMetadataRepository.java               💾 REPOSITORY EXAMPLE
│   │
│   └── service/
│       └── RlenDataFetcherService.java               🔧 SERVICE EXAMPLE
│
├── src/main/resources/
│   └── application-hibernate.yml                     ⚙️ CONFIG
│
└── pom.xml                                           📦 DEPENDENCIES

```

## 📋 Files Overview

### Core Configuration Files (REQUIRED)

#### 1. SnowflakeHibernateConfiguration.java ⭐⭐⭐
**Purpose:** Main Hibernate/JPA configuration  
**What it does:**
- Wraps your external `SnowflakeDatasource` with HikariCP
- Configures Hibernate EntityManagerFactory
- Sets up JPA Transaction Manager
- Enables Spring Data JPA repositories

**You MUST customize:**
```java
Line 23: basePackages = "YOUR.PACKAGE.repository"
Line 62: em.setPackagesToScan("YOUR.PACKAGE.model")
```

**Dependencies:**
- Needs your external library with `SnowflakeDatasource`
- Needs `SnowflakeDbConfigProperties`

---

#### 2. SnowflakeDialect.java ⭐⭐⭐
**Purpose:** Custom Hibernate dialect for Snowflake  
**What it does:**
- Maps Snowflake data types to Hibernate types
- Provides Snowflake-specific SQL functions
- Handles case-sensitivity and naming

**You MUST:**
- Copy this file as-is (no changes needed)
- Reference it in application.yml

**No customization needed** ✅

---

#### 3. SnowflakeDbConfigProperties.java ⭐⭐
**Purpose:** Configuration properties class  
**What it does:**
- Defines all Snowflake connection properties
- Defines HikariCP pool settings
- Maps to application.yml configuration

**You might customize:**
- Add/remove properties based on your needs
- Adjust default pool sizes

---

#### 4. application-hibernate.yml ⭐⭐⭐
**Purpose:** Application configuration  
**What it does:**
- Defines Snowflake connection details
- Configures HikariCP pool
- Sets Hibernate properties
- Configures logging

**You MUST customize:**
```yaml
Line 4-9: Your Snowflake connection details
Line 33: Point to your SnowflakeDialect class
```

---

#### 5. pom.xml ⭐⭐⭐
**Purpose:** Maven dependencies  
**What it does:**
- Adds Spring Data JPA
- Adds Hibernate
- Adds Snowflake JDBC driver
- Adds HikariCP

**You MUST customize:**
```xml
Line 64-68: Add your external library dependency
```

---

### Example Files (REFERENCE)

#### 6. RlenMetadata.java 📋
**Purpose:** Example JPA entity  
**Use this as:**
- Template for creating your own entities
- Reference for Snowflake-specific mappings

**Key patterns:**
```java
- @Entity and @Table annotations
- Sequence-based ID generation
- Column name mapping
- Data type mapping
```

---

#### 7. RlenMetadataRepository.java 💾
**Purpose:** Example Spring Data JPA repository  
**Use this as:**
- Template for your repositories
- Reference for query methods
- Reference for native queries

**Key patterns:**
```java
- Extending JpaRepository
- Query method naming
- @Query annotations
- Native SQL queries
```

---

#### 8. RlenDataFetcherService.java 🔧
**Purpose:** Example service layer  
**Use this as:**
- Template for your services
- Reference for transaction management
- Reference for using repositories

**Key patterns:**
```java
- @Transactional annotation
- Repository usage
- EntityManager usage
- Error handling
```

---

### Alternative Configurations (OPTIONAL)

#### 9. SnowflakeHikariConfiguration.java
**Purpose:** Alternative HikariCP setup (direct JDBC)  
**When to use:**
- If you want direct JDBC configuration
- If you don't want to wrap external datasource

**Not recommended** - use `SnowflakeHibernateConfiguration` instead

---

#### 10. SnowflakeHikariDataSourceConfiguration.java
**Purpose:** Simplified HikariCP wrapper  
**When to use:**
- If you only need connection pooling (no Hibernate)

**Not for JPA** - use `SnowflakeHibernateConfiguration` for JPA/Hibernate

---

#### 11. SnowflakeDataService.java
**Purpose:** Example JDBC-only service  
**When to use:**
- Reference for raw JDBC operations
- If not using JPA

**Use `RlenDataFetcherService` instead** for JPA examples

---

#### 12. application.yml
**Purpose:** Basic configuration (no Hibernate)  
**Use:** `application-hibernate.yml` instead for JPA setup

---

### Documentation Files

#### 13. QUICK-START.md ⭐⭐⭐
**START HERE!**  
Visual guide with step-by-step instructions

#### 14. HIBERNATE-README.md ⭐⭐
Comprehensive documentation for Hibernate setup

#### 15. README.md ⭐
Documentation for HikariCP-only setup (no Hibernate)

---

## 🚀 Implementation Priority

### Phase 1: Core Setup (MUST DO)
1. ✅ Copy `pom.xml` dependencies
2. ✅ Add `SnowflakeHibernateConfiguration.java`
3. ✅ Add `SnowflakeDialect.java`
4. ✅ Add `SnowflakeDbConfigProperties.java`
5. ✅ Configure `application-hibernate.yml`

### Phase 2: Entity Layer (MUST DO)
6. ✅ Create your entity classes (use `RlenMetadata.java` as template)
7. ✅ Create Snowflake sequences for IDs

### Phase 3: Repository Layer (MUST DO)
8. ✅ Create your repositories (use `RlenMetadataRepository.java` as template)

### Phase 4: Service Layer (MUST DO)
9. ✅ Create your services (use `RlenDataFetcherService.java` as template)
10. ✅ Add @Transactional annotations

### Phase 5: Testing
11. ✅ Test connection
12. ✅ Test CRUD operations
13. ✅ Monitor connection pool

---

## 📊 File Dependencies

```
application-hibernate.yml
    ↓
SnowflakeDbConfigProperties.java
    ↓
SnowflakeHibernateConfiguration.java
    ├→ SnowflakeDialect.java
    ├→ External SnowflakeDatasource (from dependency)
    └→ HikariCP
        ↓
    EntityManagerFactory (Hibernate)
        ↓
    Your Repositories
        ↓
    Your Services
        ↓
    Your Controllers
```

---

## 🎯 Quick Decision Guide

### "I want to use JPA/Hibernate"
✅ Use:
- SnowflakeHibernateConfiguration.java
- SnowflakeDialect.java
- application-hibernate.yml
- RlenMetadata.java (as template)
- RlenMetadataRepository.java (as template)
- RlenDataFetcherService.java (as template)

❌ Don't use:
- SnowflakeHikariConfiguration.java
- SnowflakeHikariDataSourceConfiguration.java
- SnowflakeDataService.java
- application.yml

### "I only want connection pooling (no JPA)"
✅ Use:
- SnowflakeHikariDataSourceConfiguration.java
- application.yml
- SnowflakeDataService.java (as template)

❌ Don't use:
- Hibernate-related files

---

## 📝 Customization Checklist

### In SnowflakeHibernateConfiguration.java:
- [ ] Line 23: Update repository base package
- [ ] Line 62: Update entity scan package
- [ ] Line 40: Verify external datasource bean name

### In application-hibernate.yml:
- [ ] Lines 4-9: Add your Snowflake credentials
- [ ] Line 33: Verify dialect class path
- [ ] Lines 50-56: Adjust logging levels

### In pom.xml:
- [ ] Lines 64-68: Add your external library
- [ ] Verify Spring Boot version matches your project

### Create Your Own:
- [ ] Entity classes based on RlenMetadata.java
- [ ] Repositories based on RlenMetadataRepository.java
- [ ] Services based on RlenDataFetcherService.java

---

## ⚠️ Common Mistakes

### ❌ Using wrong configuration file
**Wrong:** Using `SnowflakeHikariConfiguration` for JPA  
**Right:** Use `SnowflakeHibernateConfiguration` for JPA

### ❌ Forgetting to customize packages
**Wrong:** Leaving default package names  
**Right:** Update to your actual packages

### ❌ Using wrong application.yml
**Wrong:** Using `application.yml` for Hibernate setup  
**Right:** Use `application-hibernate.yml`

### ❌ Missing external dependency
**Wrong:** Not adding your SnowflakeDatasource library  
**Right:** Add it to pom.xml dependencies section

---

## 📞 Support

### If something doesn't work:

1. **Check this file first** for correct file usage
2. **Read QUICK-START.md** for step-by-step guide
3. **Read HIBERNATE-README.md** for detailed documentation
4. **Check logs** for specific errors
5. **Verify customizations** using checklists above

### Common issues:
- "Table not found" → Check entity @Table name matches Snowflake
- "Bean not found" → Check external library is imported
- "Sequence doesn't exist" → Create sequence in Snowflake
- "Wrong dialect" → Check application.yml dialect property

---

## ✅ Verification

After implementation, verify:
- [ ] Application starts without errors
- [ ] HikariCP pool initializes (check logs)
- [ ] Hibernate validates schema (check logs)
- [ ] Can query database via repository
- [ ] Can save entities
- [ ] Transactions work correctly
- [ ] Connection pool metrics available

---

## 🎓 Learning Path

1. **Start:** Read QUICK-START.md
2. **Implement:** Follow Phase 1-4 above
3. **Understand:** Read HIBERNATE-README.md
4. **Customize:** Adapt example files to your needs
5. **Optimize:** Tune pool settings and queries

---

Good luck with your implementation! 🚀
