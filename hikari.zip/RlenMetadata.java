import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Example JPA Entity for Snowflake based on your RlenMetadata model
 * 
 * Key considerations for Snowflake entities:
 * 1. Use @Table to specify exact table name (Snowflake is case-sensitive when quoted)
 * 2. Use sequences for ID generation instead of AUTO strategy
 * 3. Map Snowflake data types appropriately
 * 4. Avoid using features Snowflake doesn't support (like foreign keys in some cases)
 */
@Entity
@Table(name = "RLEN_METADATA", schema = "YOUR_SCHEMA")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RlenMetadata {

    /**
     * Primary key using Snowflake sequence
     * Snowflake supports sequences for auto-generating IDs
     */
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rlen_metadata_seq")
    @SequenceGenerator(
        name = "rlen_metadata_seq",
        sequenceName = "RLEN_METADATA_SEQ",
        allocationSize = 1
    )
    @Column(name = "ID", nullable = false)
    private Long id;

    @Column(name = "RUN_ID", nullable = false, length = 100)
    private String runId;

    @Column(name = "LE_ID", nullable = false, length = 100)
    private String leId;

    @Column(name = "COB_DATE", nullable = false)
    private LocalDate cobDate;

    @Column(name = "CONSOLIDATION_CODE", length = 50)
    private String consolidationCode;

    /**
     * For VARCHAR columns in Snowflake, specify length
     */
    @Column(name = "ENTITY_NAME", length = 500)
    private String entityName;

    /**
     * Snowflake NUMBER type mapping
     */
    @Column(name = "TOTAL_AMOUNT", precision = 19, scale = 2)
    private BigDecimal totalAmount;

    /**
     * Snowflake BOOLEAN type
     */
    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    /**
     * Snowflake TIMESTAMP_NTZ type
     * Use @CreationTimestamp for auto-population
     */
    @CreationTimestamp
    @Column(name = "CREATED_AT", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Use @UpdateTimestamp for auto-update
     */
    @UpdateTimestamp
    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @Column(name = "CREATED_BY", length = 100)
    private String createdBy;

    @Column(name = "UPDATED_BY", length = 100)
    private String updatedBy;

    /**
     * For TEXT/CLOB columns in Snowflake
     */
    @Lob
    @Column(name = "NOTES", columnDefinition = "TEXT")
    private String notes;

    /**
     * Snowflake VARIANT type (JSON)
     * Store as String and parse manually or use custom types
     */
    @Column(name = "METADATA_JSON", columnDefinition = "VARIANT")
    private String metadataJson;

    /**
     * Enum mapping example
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", length = 50)
    private ProcessingStatus status;

    public enum ProcessingStatus {
        PENDING,
        PROCESSING,
        COMPLETED,
        FAILED
    }
}
