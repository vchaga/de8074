import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Service layer for RlenMetadata operations
 * 
 * This service demonstrates:
 * 1. Using the JPA repository with HikariCP-pooled connections
 * 2. Transaction management with Snowflake
 * 3. Integration with your validator pattern
 */
@Slf4j
@Service
public class RlenDataFetcherService {

    private final RlenMetadataRepository rlenMetadataRepository;

    // EntityManager for more complex operations
    @PersistenceContext(unitName = "snowflakePersistenceUnit")
    private EntityManager entityManager;

    public RlenDataFetcherService(RlenMetadataRepository rlenMetadataRepository) {
        this.rlenMetadataRepository = rlenMetadataRepository;
    }

    /**
     * Validation method matching your RlenDataFetcherValidator pattern
     * This uses the HikariCP-pooled connection via JPA
     */
    @Transactional(
        value = "snowflakeTransactionManager",
        readOnly = true
    )
    public ValidationResponse runRlenDataValidation(
            String runId,
            String leId,
            String cobDate,
            String consolidationCode) {
        
        try {
            log.info("Validating RLEN Adjustment Template data");
            log.info("Input data used for validation: runId: {}, leId: {}, cobDate: {}, consolidationCode: {}",
                    runId, leId, cobDate, consolidationCode);

            LocalDate cobDateParsed = LocalDate.parse(cobDate);

            // Use the repository to find metadata
            // This automatically uses the HikariCP connection pool
            Optional<RlenMetadata> rlenMetadata = rlenMetadataRepository
                    .findByRunIdAndLeIdAndCobDateAndConsolidationCode(
                            runId, leId, cobDateParsed, consolidationCode);

            if (rlenMetadata.isPresent()) {
                log.info("Run Id Found");
                return new ValidationResponse(
                        true,
                        "Run Id Found",
                        rlenMetadata.get()
                );
            } else {
                log.info("Run Id Not Found");
                return new ValidationResponse(
                        false,
                        "Run Id Not Found",
                        null
                );
            }
        } catch (Exception e) {
            log.error("Exception occurred while reading metadata", e);
            return new ValidationResponse(
                    false,
                    "Error during validation: " + e.getMessage(),
                    null
            );
        }
    }

    /**
     * Save or update metadata
     * Transaction automatically commits on success, rolls back on exception
     */
    @Transactional(value = "snowflakeTransactionManager")
    public RlenMetadata saveMetadata(RlenMetadata metadata) {
        log.info("Saving metadata for runId: {}", metadata.getRunId());
        RlenMetadata saved = rlenMetadataRepository.save(metadata);
        log.info("Successfully saved metadata with ID: {}", saved.getId());
        return saved;
    }

    /**
     * Batch save operation
     */
    @Transactional(value = "snowflakeTransactionManager")
    public List<RlenMetadata> saveAllMetadata(List<RlenMetadata> metadataList) {
        log.info("Batch saving {} metadata records", metadataList.size());
        List<RlenMetadata> saved = rlenMetadataRepository.saveAll(metadataList);
        log.info("Successfully batch saved {} records", saved.size());
        return saved;
    }

    /**
     * Find all records for a run
     */
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public List<RlenMetadata> findByRunId(String runId) {
        log.info("Finding metadata for runId: {}", runId);
        return rlenMetadataRepository.findByRunId(runId);
    }

    /**
     * Get aggregated data using native Snowflake queries
     */
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public List<Object[]> getAggregatedData(String runId) {
        log.info("Getting aggregated data for runId: {}", runId);
        return rlenMetadataRepository.getAggregatedDataByRunId(runId);
    }

    /**
     * Check if record exists (useful for validation)
     */
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public boolean recordExists(String runId, String leId, LocalDate cobDate, String consolidationCode) {
        return rlenMetadataRepository.existsByRunIdAndLeIdAndCobDateAndConsolidationCode(
                runId, leId, cobDate, consolidationCode);
    }

    /**
     * Example using EntityManager for complex queries
     * Useful when you need more control than repositories provide
     */
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public List<RlenMetadata> findWithComplexCriteria(String runId, LocalDate startDate, LocalDate endDate) {
        String jpql = """
                SELECT r FROM RlenMetadata r
                WHERE r.runId = :runId
                AND r.cobDate BETWEEN :startDate AND :endDate
                AND r.isActive = true
                ORDER BY r.cobDate DESC
                """;

        return entityManager.createQuery(jpql, RlenMetadata.class)
                .setParameter("runId", runId)
                .setParameter("startDate", startDate)
                .setParameter("endDate", endDate)
                .getResultList();
    }

    /**
     * Example of executing native Snowflake SQL with EntityManager
     * Use this for Snowflake-specific features
     */
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public List<Object[]> executeNativeSnowflakeQuery(String runId) {
        String nativeSql = """
                SELECT 
                    RUN_ID,
                    COB_DATE,
                    COUNT(*) as record_count,
                    SUM(TOTAL_AMOUNT) as total_amount,
                    DATE_TRUNC('month', COB_DATE) as month_start
                FROM RLEN_METADATA
                WHERE RUN_ID = :runId
                GROUP BY RUN_ID, COB_DATE
                ORDER BY COB_DATE DESC
                """;

        return entityManager.createNativeQuery(nativeSql)
                .setParameter("runId", runId)
                .getResultList();
    }

    /**
     * Delete with transaction
     */
    @Transactional(value = "snowflakeTransactionManager")
    public void deleteById(Long id) {
        log.info("Deleting metadata with ID: {}", id);
        rlenMetadataRepository.deleteById(id);
        log.info("Successfully deleted metadata");
    }

    /**
     * Response object for validation
     */
    public record ValidationResponse(
            boolean found,
            String message,
            RlenMetadata data
    ) {}
}
