import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * JPA Repository for RlenMetadata
 * 
 * Based on your code structure, this repository provides:
 * - Standard CRUD operations via JpaRepository
 * - Custom queries using @Query annotation
 * - Native Snowflake SQL support
 */
@Repository
public interface RlenMetadataRepository extends JpaRepository<RlenMetadata, Long> {

    /**
     * Find by composite business key (runId, leId, cobDate, consolidationCode)
     * This matches the pattern from your validator code
     */
    Optional<RlenMetadata> findByRunIdAndLeIdAndCobDateAndConsolidationCode(
            String runId,
            String leId,
            LocalDate cobDate,
            String consolidationCode
    );

    /**
     * Check if record exists - useful for validation
     */
    boolean existsByRunIdAndLeIdAndCobDateAndConsolidationCode(
            String runId,
            String leId,
            LocalDate cobDate,
            String consolidationCode
    );

    /**
     * Find all records for a specific run
     */
    List<RlenMetadata> findByRunId(String runId);

    /**
     * Find records by COB date range
     */
    List<RlenMetadata> findByCobDateBetween(LocalDate startDate, LocalDate endDate);

    /**
     * Find records by status
     */
    List<RlenMetadata> findByStatus(RlenMetadata.ProcessingStatus status);

    /**
     * Custom JPQL query example
     */
    @Query("SELECT r FROM RlenMetadata r WHERE r.runId = :runId AND r.isActive = true")
    List<RlenMetadata> findActiveByRunId(@Param("runId") String runId);

    /**
     * Native Snowflake SQL query example
     * Use this for Snowflake-specific features not supported in JPQL
     */
    @Query(value = """
            SELECT * FROM RLEN_METADATA
            WHERE RUN_ID = :runId
            AND COB_DATE >= DATEADD(day, -30, CURRENT_DATE())
            ORDER BY CREATED_AT DESC
            """, nativeQuery = true)
    List<RlenMetadata> findRecentByRunIdNative(@Param("runId") String runId);

    /**
     * Aggregate query example using Snowflake functions
     */
    @Query(value = """
            SELECT COB_DATE, COUNT(*) as record_count, SUM(TOTAL_AMOUNT) as total_sum
            FROM RLEN_METADATA
            WHERE RUN_ID = :runId
            GROUP BY COB_DATE
            ORDER BY COB_DATE DESC
            """, nativeQuery = true)
    List<Object[]> getAggregatedDataByRunId(@Param("runId") String runId);

    /**
     * Delete old records - useful for data retention
     */
    @Query("DELETE FROM RlenMetadata r WHERE r.cobDate < :cutoffDate")
    void deleteOldRecords(@Param("cutoffDate") LocalDate cutoffDate);

    /**
     * Find records with specific consolidation code
     */
    List<RlenMetadata> findByConsolidationCodeIn(List<String> consolidationCodes);

    /**
     * Count records by run ID
     */
    long countByRunId(String runId);

    /**
     * Find top N records
     */
    List<RlenMetadata> findTop10ByOrderByCreatedAtDesc();
}
