import org.hibernate.dialect.PostgreSQLDialect;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.type.StandardBasicTypes;

import java.sql.Types;

/**
 * Custom Hibernate Dialect for Snowflake
 * 
 * Snowflake doesn't have an official Hibernate dialect, so we extend PostgreSQLDialect
 * as it's the closest match to Snowflake's SQL syntax.
 * 
 * This dialect handles Snowflake-specific quirks and limitations:
 * - No support for AUTO_INCREMENT (use sequences instead)
 * - Limited DDL operation support
 * - Case-sensitive identifiers (uppercase by default)
 * - Specific data type mappings
 */
public class SnowflakeDialect extends PostgreSQLDialect {

    public SnowflakeDialect() {
        super();
        
        // Register Snowflake-specific functions
        registerFunction("dateadd", new StandardSQLFunction("dateadd"));
        registerFunction("datediff", new StandardSQLFunction("datediff", StandardBasicTypes.INTEGER));
        registerFunction("date_trunc", new StandardSQLFunction("date_trunc", StandardBasicTypes.TIMESTAMP));
        registerFunction("current_timestamp", new StandardSQLFunction("current_timestamp", StandardBasicTypes.TIMESTAMP));
        registerFunction("to_timestamp", new StandardSQLFunction("to_timestamp", StandardBasicTypes.TIMESTAMP));
        registerFunction("to_date", new StandardSQLFunction("to_date", StandardBasicTypes.DATE));
        registerFunction("to_varchar", new StandardSQLFunction("to_varchar", StandardBasicTypes.STRING));
        registerFunction("try_cast", new StandardSQLFunction("try_cast"));
        registerFunction("iff", new StandardSQLFunction("iff"));
        registerFunction("array_agg", new StandardSQLFunction("array_agg"));
        registerFunction("object_construct", new StandardSQLFunction("object_construct"));
        
        // Snowflake data type mappings
        registerColumnType(Types.BOOLEAN, "BOOLEAN");
        registerColumnType(Types.TINYINT, "NUMBER(3,0)");
        registerColumnType(Types.SMALLINT, "NUMBER(5,0)");
        registerColumnType(Types.INTEGER, "NUMBER(10,0)");
        registerColumnType(Types.BIGINT, "NUMBER(19,0)");
        registerColumnType(Types.FLOAT, "FLOAT");
        registerColumnType(Types.DOUBLE, "DOUBLE");
        registerColumnType(Types.DECIMAL, "NUMBER($p,$s)");
        registerColumnType(Types.NUMERIC, "NUMBER($p,$s)");
        
        registerColumnType(Types.CHAR, "VARCHAR($l)");
        registerColumnType(Types.VARCHAR, "VARCHAR($l)");
        registerColumnType(Types.LONGVARCHAR, "TEXT");
        registerColumnType(Types.CLOB, "TEXT");
        
        registerColumnType(Types.DATE, "DATE");
        registerColumnType(Types.TIME, "TIME");
        registerColumnType(Types.TIMESTAMP, "TIMESTAMP_NTZ");
        
        registerColumnType(Types.BINARY, "BINARY");
        registerColumnType(Types.VARBINARY, "BINARY");
        registerColumnType(Types.BLOB, "BINARY");
    }

    @Override
    public String getAddColumnString() {
        return "add column";
    }

    @Override
    public boolean supportsIdentityColumns() {
        // Snowflake supports identity columns (AUTOINCREMENT)
        return true;
    }

    @Override
    public String getIdentityColumnString() {
        // Snowflake uses AUTOINCREMENT for identity columns
        return "autoincrement";
    }

    @Override
    public String getIdentitySelectString() {
        // Get the last inserted ID - Snowflake doesn't have a direct equivalent
        // Use sequence or return clause instead
        return "select last_query_id()";
    }

    @Override
    public boolean supportsLimit() {
        return true;
    }

    @Override
    public String getLimitString(String sql, boolean hasOffset) {
        return sql + (hasOffset ? " limit ? offset ?" : " limit ?");
    }

    @Override
    public boolean bindLimitParametersInReverseOrder() {
        return false;
    }

    @Override
    public boolean supportsCurrentTimestampSelection() {
        return true;
    }

    @Override
    public String getCurrentTimestampSelectString() {
        return "select current_timestamp()";
    }

    @Override
    public boolean isCurrentTimestampSelectStringCallable() {
        return false;
    }

    @Override
    public boolean supportsUnionAll() {
        return true;
    }

    @Override
    public boolean supportsCommentOn() {
        return true;
    }

    @Override
    public boolean supportsSequences() {
        return true;
    }

    @Override
    public String getSequenceNextValString(String sequenceName) {
        return "select " + sequenceName + ".nextval";
    }

    @Override
    public String getCreateSequenceString(String sequenceName) {
        return "create sequence " + sequenceName;
    }

    @Override
    public String getDropSequenceString(String sequenceName) {
        return "drop sequence " + sequenceName;
    }

    @Override
    public boolean supportsPooledSequences() {
        return true;
    }

    @Override
    public boolean supportsLockTimeouts() {
        return false;
    }

    @Override
    public boolean supportsOuterJoinForUpdate() {
        return false;
    }

    @Override
    public String getForUpdateString() {
        return ""; // Snowflake doesn't support SELECT...FOR UPDATE
    }

    @Override
    public boolean supportsRowValueConstructorSyntax() {
        return true;
    }

    @Override
    public boolean supportsRowValueConstructorSyntaxInInList() {
        return true;
    }

    /**
     * Snowflake identifiers are case-insensitive and stored in uppercase by default
     * Quote them to preserve case
     */
    @Override
    public String quote(String name) {
        return "\"" + name + "\"";
    }
}
