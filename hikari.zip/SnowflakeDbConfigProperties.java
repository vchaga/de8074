import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "snowflake.datasource")
public class SnowflakeDbConfigProperties {

    private String jdbcUrl;
    private String username;
    private String password;
    private String warehouse;
    private String database;
    private String schema;
    private String role;
    
    // HikariCP Connection Pool Settings
    private Integer maximumPoolSize = 10;
    private Integer minimumIdle = 2;
    private Long connectionTimeout = 30000L; // 30 seconds
    private Long validationTimeout = 5000L; // 5 seconds
    private Long idleTimeout = 600000L; // 10 minutes
    private Long maxLifetime = 1800000L; // 30 minutes
    private String connectionTestQuery = "SELECT 1";
    private String connectionInitSql;
    
    // EPV Configuration
    private EpvConfig epv = new EpvConfig();
    
    // Gaia Properties
    private SnowflakeDbGaiaProperties gaiaProperties;

    // Getters and Setters
    public String getJdbcUrl() {
        return jdbcUrl;
    }

    public void setJdbcUrl(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse;
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Integer getMaximumPoolSize() {
        return maximumPoolSize;
    }

    public void setMaximumPoolSize(Integer maximumPoolSize) {
        this.maximumPoolSize = maximumPoolSize;
    }

    public Integer getMinimumIdle() {
        return minimumIdle;
    }

    public void setMinimumIdle(Integer minimumIdle) {
        this.minimumIdle = minimumIdle;
    }

    public Long getConnectionTimeout() {
        return connectionTimeout;
    }

    public void setConnectionTimeout(Long connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    public Long getValidationTimeout() {
        return validationTimeout;
    }

    public void setValidationTimeout(Long validationTimeout) {
        this.validationTimeout = validationTimeout;
    }

    public Long getIdleTimeout() {
        return idleTimeout;
    }

    public void setIdleTimeout(Long idleTimeout) {
        this.idleTimeout = idleTimeout;
    }

    public Long getMaxLifetime() {
        return maxLifetime;
    }

    public void setMaxLifetime(Long maxLifetime) {
        this.maxLifetime = maxLifetime;
    }

    public String getConnectionTestQuery() {
        return connectionTestQuery;
    }

    public void setConnectionTestQuery(String connectionTestQuery) {
        this.connectionTestQuery = connectionTestQuery;
    }

    public String getConnectionInitSql() {
        return connectionInitSql;
    }

    public void setConnectionInitSql(String connectionInitSql) {
        this.connectionInitSql = connectionInitSql;
    }

    public EpvConfig getEpv() {
        return epv;
    }

    public void setEpv(EpvConfig epv) {
        this.epv = epv;
    }

    public SnowflakeDbGaiaProperties getGaiaProperties() {
        return gaiaProperties;
    }

    public void setGaiaProperties(SnowflakeDbGaiaProperties gaiaProperties) {
        this.gaiaProperties = gaiaProperties;
    }

    // Inner class for EPV configuration
    public static class EpvConfig {
        private Boolean useEpv = false;
        private String objectName;

        public Boolean getUseEpv() {
            return useEpv;
        }

        public void setUseEpv(Boolean useEpv) {
            this.useEpv = useEpv;
        }

        public String getObjectName() {
            return objectName;
        }

        public void setObjectName(String objectName) {
            this.objectName = objectName;
        }
    }
}
