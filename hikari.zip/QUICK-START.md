# Complete Snowflake Hibernate Setup - Quick Start Guide

## 📋 What You Have

Your situation:
- ✅ External library containing `SnowflakeDatasource` class
- ✅ ADFS token authentication
- ✅ EPV/Gaia credential management
- ✅ Need to integrate with Hibernate/JPA

## 🎯 What This Solution Provides

```
┌─────────────────────────────────────────────────────────────────┐
│                     YOUR APPLICATION                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌────────────────┐       ┌─────────────────┐                  │
│  │  Controllers   │──────▶│   Services      │                  │
│  │  (REST APIs)   │       │  (@Service)     │                  │
│  └────────────────┘       └────────┬────────┘                  │
│                                     │                            │
│                                     ▼                            │
│                          ┌─────────────────────┐                │
│                          │  JPA Repositories   │                │
│                          │  (Spring Data JPA)  │                │
│                          └──────────┬──────────┘                │
├─────────────────────────────────────┼───────────────────────────┤
│              HIBERNATE/JPA LAYER    │                           │
├─────────────────────────────────────┼───────────────────────────┤
│                                     ▼                            │
│                          ┌─────────────────────┐                │
│                          │  EntityManager      │                │
│                          │  (Hibernate)        │                │
│                          └──────────┬──────────┘                │
│                                     │                            │
│                                     ▼                            │
│                          ┌─────────────────────┐                │
│                          │  TransactionManager │                │
│                          │  (JPA Transactions) │                │
│                          └──────────┬──────────┘                │
├─────────────────────────────────────┼───────────────────────────┤
│           CONNECTION POOLING        │                           │
├─────────────────────────────────────┼───────────────────────────┤
│                                     ▼                            │
│                          ┌─────────────────────┐                │
│                          │   HikariCP Pool     │                │
│                          │  (10 connections)   │                │
│                          └──────────┬──────────┘                │
├─────────────────────────────────────┼───────────────────────────┤
│        EXTERNAL LIBRARY             │                           │
├─────────────────────────────────────┼───────────────────────────┤
│                                     ▼                            │
│                     ┌──────────────────────────────┐            │
│                     │  SnowflakeDatasource         │            │
│                     │  - ADFS Token Provider       │            │
│                     │  - Gaia Credentials Service  │            │
│                     │  - EPV Integration           │            │
│                     └──────────────┬───────────────┘            │
└─────────────────────────────────────┼───────────────────────────┘
                                      │
                                      ▼
                         ┌─────────────────────────┐
                         │   SNOWFLAKE DATABASE    │
                         └─────────────────────────┘
```

## 🚀 Implementation Checklist

### Step 1: Add Dependencies (5 min)
- [ ] Copy `pom.xml` dependencies to your project
- [ ] Run `mvn clean install`

**Key dependencies:**
```xml
- spring-boot-starter-data-jpa
- snowflake-jdbc (3.14.5)
- HikariCP (5.1.0)
- hibernate-core
- your-external-snowflake-library
```

### Step 2: Add Configuration Files (10 min)

#### File 1: SnowflakeHibernateConfiguration.java
**Location:** `src/main/java/com/jpmorgan/ct/config/`

**What it does:**
- Creates HikariCP datasource wrapping your external `SnowflakeDatasource`
- Configures Hibernate EntityManagerFactory
- Sets up JPA transaction management

**Key customizations needed:**
```java
@EnableJpaRepositories(
    basePackages = "com.jpmorgan.ct.snowflakejpa.repository", // ← UPDATE THIS
    entityManagerFactoryRef = "snowflakeEntityManagerFactory",
    transactionManagerRef = "snowflakeTransactionManager"
)
```

```java
em.setPackagesToScan(
    "com.jpmorgan.ct.snowflakejpa.model" // ← UPDATE THIS
);
```

#### File 2: SnowflakeDialect.java
**Location:** `src/main/java/com/jpmorgan/ct/config/`

**What it does:**
- Provides Snowflake-specific SQL dialect for Hibernate
- Maps data types correctly
- Handles Snowflake functions

**No changes needed** - use as-is

#### File 3: application.yml
**Location:** `src/main/resources/`

**Key configurations:**
```yaml
snowflake:
  datasource:
    jdbc-url: jdbc:snowflake://YOUR-ACCOUNT.snowflakecomputing.com/
    username: ${SNOWFLAKE_USERNAME}
    password: ${SNOWFLAKE_PASSWORD}
    warehouse: YOUR_WAREHOUSE
    database: YOUR_DATABASE
    schema: YOUR_SCHEMA
    maximum-pool-size: 10
    minimum-idle: 2

spring:
  jpa:
    hibernate:
      ddl-auto: validate  # IMPORTANT!
    properties:
      hibernate:
        dialect: com.jpmorgan.ct.config.SnowflakeDialect
```

### Step 3: Create Your Entity Models (15 min)

#### Example: RlenMetadata.java
**Location:** `src/main/java/com/jpmorgan/ct/snowflakejpa/model/`

```java
@Entity
@Table(name = "RLEN_METADATA", schema = "YOUR_SCHEMA")
public class RlenMetadata {
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rlen_seq")
    @SequenceGenerator(name = "rlen_seq", sequenceName = "RLEN_METADATA_SEQ")
    private Long id;
    
    @Column(name = "RUN_ID")
    private String runId;
    
    // ... map all your fields
}
```

**Critical points:**
- ✅ Use `@Table(name = "TABLE_NAME")` with exact Snowflake table name
- ✅ Use sequences for `@Id` generation
- ✅ Map column names exactly: `@Column(name = "COL_NAME")`
- ❌ Don't use `GenerationType.AUTO` or `IDENTITY`

### Step 4: Create Repositories (5 min)

#### Example: RlenMetadataRepository.java
**Location:** `src/main/java/com/jpmorgan/ct/snowflakejpa/repository/`

```java
@Repository
public interface RlenMetadataRepository extends JpaRepository<RlenMetadata, Long> {
    
    Optional<RlenMetadata> findByRunIdAndLeIdAndCobDateAndConsolidationCode(
        String runId, String leId, LocalDate cobDate, String consolidationCode
    );
    
    List<RlenMetadata> findByRunId(String runId);
    
    @Query(value = "SELECT * FROM RLEN_METADATA WHERE RUN_ID = :runId", 
           nativeQuery = true)
    List<RlenMetadata> customQuery(@Param("runId") String runId);
}
```

**No Spring Data JPA implementation needed** - it's auto-generated!

### Step 5: Update Service Layer (10 min)

#### Example: RlenDataFetcherService.java
**Location:** `src/main/java/com/jpmorgan/ct/service/`

```java
@Service
public class RlenDataFetcherService {
    
    private final RlenMetadataRepository repository;
    
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public ValidationResponse runRlenDataValidation(
            String runId, String leId, String cobDate, String consolidationCode) {
        
        Optional<RlenMetadata> metadata = repository
            .findByRunIdAndLeIdAndCobDateAndConsolidationCode(
                runId, leId, LocalDate.parse(cobDate), consolidationCode
            );
        
        return metadata.isPresent()
            ? new ValidationResponse(true, "Found", metadata.get())
            : new ValidationResponse(false, "Not Found", null);
    }
    
    @Transactional(value = "snowflakeTransactionManager")
    public RlenMetadata save(RlenMetadata entity) {
        return repository.save(entity);
    }
}
```

**Key points:**
- ✅ Always use `@Transactional(value = "snowflakeTransactionManager")`
- ✅ Use `readOnly = true` for read operations
- ✅ No manual connection management needed!

### Step 6: Configure External Dependency (CRITICAL) (5 min)

Your external library must be available as a Spring bean:

**Option A: If your library provides @Configuration**
```java
// Import the configuration
@Import(YourLibraryConfiguration.class)
@SpringBootApplication
public class Application {
    // ...
}
```

**Option B: If you need to create the bean manually**
```java
@Configuration
public class ExternalDependencyConfig {
    
    @Bean(name = "snowflakeDatasource")
    public SnowflakeDatasource snowflakeDatasource(
            /* inject required dependencies */) {
        return new SnowflakeDatasource(/* constructor params */);
    }
}
```

Then in `SnowflakeHibernateConfiguration`:
```java
public SnowflakeHibernateConfiguration(
        SnowflakeDbConfigProperties properties,
        @Qualifier("snowflakeDatasource") SnowflakeDatasource externalSnowflakeDatasource) {
    // ...
}
```

### Step 7: Test the Setup (10 min)

```java
@SpringBootTest
class IntegrationTest {
    
    @Autowired
    private RlenMetadataRepository repository;
    
    @Test
    void testConnection() {
        List<RlenMetadata> all = repository.findAll();
        assertNotNull(all);
    }
}
```

## 🔍 Verification Steps

### 1. Check HikariCP Pool Initialization
Look for logs:
```
Snowflake HikariCP DataSource configured: maxPoolSize=10, minIdle=2
```

### 2. Check Hibernate Initialization
Look for logs:
```
HHH000412: Hibernate ORM core version [X.X.X]
```

### 3. Check Entity Mapping
Look for logs:
```
Hibernate: select ... from RLEN_METADATA ...
```

### 4. Test Connection
```bash
curl http://localhost:8080/actuator/health
```

Should show:
```json
{
  "status": "UP",
  "components": {
    "db": {
      "status": "UP",
      "details": {
        "database": "Snowflake"
      }
    }
  }
}
```

## 🎓 Key Concepts

### How Connections Work

1. **Service calls repository**
   ```java
   repository.findByRunId("RUN001");
   ```

2. **Hibernate requests connection from HikariCP**
   - HikariCP checks pool
   - If connection available: Reuse it
   - If not: Call `externalSnowflakeDatasource.getConnection()`

3. **External datasource creates connection**
   - Refreshes ADFS token
   - Gets password from EPV/Gaia
   - Authenticates to Snowflake
   - Returns connection

4. **HikariCP adds to pool**
   - Connection used for query
   - Returned to pool (not closed!)

5. **Next request reuses pooled connection**
   - No token refresh needed
   - No authentication needed
   - Instant connection!

### Transaction Boundaries

```java
@Transactional  // ← Transaction starts here
public void processData() {
    repository.save(entity1);  // Same connection
    repository.save(entity2);  // Same connection
    // If no exception: COMMIT
    // If exception: ROLLBACK
} // ← Transaction ends here
```

## ⚠️ Common Pitfalls

### ❌ Wrong: Using GenerationType.AUTO
```java
@Id
@GeneratedValue(strategy = GenerationType.AUTO)  // DON'T DO THIS
private Long id;
```

### ✅ Right: Using Sequences
```java
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq")
@SequenceGenerator(name = "my_seq", sequenceName = "MY_SEQ")
private Long id;
```

---

### ❌ Wrong: Letting Hibernate create schema
```yaml
spring:
  jpa:
    hibernate:
      ddl-auto: create  # NEVER DO THIS
```

### ✅ Right: Validating existing schema
```yaml
spring:
  jpa:
    hibernate:
      ddl-auto: validate  # ALWAYS DO THIS
```

---

### ❌ Wrong: Lowercase table names without quotes
```java
@Table(name = "my_table")  // Snowflake looks for MY_TABLE
```

### ✅ Right: Exact case or quoted
```java
@Table(name = "MY_TABLE")  // Matches Snowflake
// OR
@Table(name = "\"my_table\"")  // Preserves case
```

---

### ❌ Wrong: Forgetting @Transactional
```java
public void save(Entity e) {
    repository.save(e);  // May not commit!
}
```

### ✅ Right: Using @Transactional
```java
@Transactional(value = "snowflakeTransactionManager")
public void save(Entity e) {
    repository.save(e);  // Commits automatically
}
```

## 📊 Monitoring

### HikariCP Metrics
```bash
# Active connections
curl http://localhost:8080/actuator/metrics/hikaricp.connections.active

# Idle connections
curl http://localhost:8080/actuator/metrics/hikaricp.connections.idle

# Pool usage
curl http://localhost:8080/actuator/metrics/hikaricp.connections.usage
```

### Hibernate Statistics
Enable in code:
```java
Statistics stats = entityManager.unwrap(Session.class)
    .getSessionFactory()
    .getStatistics();

System.out.println("Query count: " + stats.getQueryExecutionCount());
System.out.println("Cache hit ratio: " + stats.getSecondLevelCacheHitRate());
```

## 🎉 You're Done!

Your setup now provides:
- ✅ Full JPA/Hibernate ORM capabilities
- ✅ Connection pooling (10 connections by default)
- ✅ ADFS token management (via external library)
- ✅ EPV/Gaia credential support (via external library)
- ✅ Transaction management
- ✅ Spring Data JPA repositories
- ✅ No manual JDBC code needed!

## 📚 Quick Reference

| Task | Code |
|------|------|
| Find by ID | `repository.findById(id)` |
| Find all | `repository.findAll()` |
| Save | `repository.save(entity)` |
| Delete | `repository.deleteById(id)` |
| Custom query | `@Query(...)` |
| Transaction | `@Transactional` |
| Read-only | `@Transactional(readOnly=true)` |

## 🆘 Getting Help

1. Check logs for errors
2. Verify table names match Snowflake exactly
3. Check sequence exists: `SHOW SEQUENCES;`
4. Monitor connection pool metrics
5. Enable SQL logging: `spring.jpa.show-sql=true`

## 📖 Full Documentation

- [HIBERNATE-README.md](HIBERNATE-README.md) - Complete guide
- [README.md](README.md) - HikariCP setup only
