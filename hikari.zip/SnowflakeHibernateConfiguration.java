import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Hibernate/JPA Configuration for Snowflake DataSource
 * 
 * This configuration handles the case where SnowflakeDatasource is provided
 * by an external dependency and sets up:
 * - HikariCP connection pooling
 * - Hibernate EntityManagerFactory
 * - JPA Transaction Manager
 * - JPA Repository support
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    basePackages = "com.jpmorgan.ct.snowflakejpa.repository", // Update with your repository package
    entityManagerFactoryRef = "snowflakeEntityManagerFactory",
    transactionManagerRef = "snowflakeTransactionManager"
)
public class SnowflakeHibernateConfiguration {

    private final SnowflakeDbConfigProperties properties;
    
    // If SnowflakeDatasource is from external dependency, inject it here
    private final SnowflakeDatasource externalSnowflakeDatasource;

    public SnowflakeHibernateConfiguration(
            SnowflakeDbConfigProperties properties,
            @Qualifier("snowflakeDatasource") SnowflakeDatasource externalSnowflakeDatasource) {
        this.properties = properties;
        this.externalSnowflakeDatasource = externalSnowflakeDatasource;
    }

    /**
     * HikariCP DataSource wrapping the external SnowflakeDatasource
     * This provides connection pooling on top of your existing datasource
     */
    @Bean(name = "hikariSnowflakeDataSource")
    @Primary
    public HikariDataSource hikariSnowflakeDataSource() throws SQLException {
        // Test the external datasource connection first
        try (var conn = externalSnowflakeDatasource.getConnection()) {
            log.info("Successfully tested external SnowflakeDatasource connection");
        }

        // Create HikariCP configuration
        HikariConfig config = new HikariConfig();
        
        // Wrap the external datasource
        config.setDataSource(externalSnowflakeDatasource);
        
        // Configure pool settings
        config.setPoolName("SnowflakeHikariPool");
        config.setMaximumPoolSize(properties.getMaximumPoolSize() != null ? 
                properties.getMaximumPoolSize() : 10);
        config.setMinimumIdle(properties.getMinimumIdle() != null ? 
                properties.getMinimumIdle() : 2);
        config.setConnectionTimeout(properties.getConnectionTimeout() != null ? 
                properties.getConnectionTimeout() : 30000);
        config.setValidationTimeout(properties.getValidationTimeout() != null ? 
                properties.getValidationTimeout() : 5000);
        config.setIdleTimeout(600000); // 10 minutes
        config.setMaxLifetime(properties.getMaxLifetime() != null ? 
                properties.getMaxLifetime() : 1800000); // 30 minutes
        
        // Connection test query for Snowflake
        config.setConnectionTestQuery("SELECT 1");
        config.setAutoCommit(true);
        config.setLeakDetectionThreshold(60000); // 1 minute
        config.setRegisterMbeans(true);

        HikariDataSource hikariDataSource = new HikariDataSource(config);
        
        log.info("Snowflake HikariCP DataSource configured: maxPoolSize={}, minIdle={}",
                hikariDataSource.getMaximumPoolSize(),
                hikariDataSource.getMinimumIdle());
        
        return hikariDataSource;
    }

    /**
     * EntityManagerFactory for Snowflake with Hibernate
     * This is the core JPA configuration
     */
    @Bean(name = "snowflakeEntityManagerFactory")
    @Primary
    public LocalContainerEntityManagerFactoryBean snowflakeEntityManagerFactory(
            @Qualifier("hikariSnowflakeDataSource") DataSource dataSource) {
        
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource);
        
        // Set the package where your JPA entities are located
        em.setPackagesToScan(
            "com.jpmorgan.ct.snowflakejpa.model" // Update with your entity package
        );
        
        // Use Hibernate as JPA provider
        em.setPersistenceProvider(new HibernatePersistenceProvider());
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        
        // Set Hibernate properties
        em.setJpaProperties(hibernateProperties());
        
        // Set persistence unit name
        em.setPersistenceUnitName("snowflakePersistenceUnit");
        
        return em;
    }

    /**
     * Transaction Manager for Snowflake JPA operations
     */
    @Bean(name = "snowflakeTransactionManager")
    @Primary
    public PlatformTransactionManager snowflakeTransactionManager(
            @Qualifier("snowflakeEntityManagerFactory") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
        
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory.getObject());
        
        return transactionManager;
    }

    /**
     * Hibernate-specific properties for Snowflake
     */
    private Properties hibernateProperties() {
        Properties properties = new Properties();
        
        // Hibernate dialect for Snowflake
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
        // Note: Snowflake doesn't have an official Hibernate dialect, PostgreSQL is closest
        // Alternatively, create a custom dialect (see SnowflakeDialect.java)
        
        // DDL strategy - IMPORTANT: Use 'validate' or 'none' for Snowflake in production
        // Snowflake doesn't support all DDL operations that Hibernate might attempt
        properties.setProperty("hibernate.hbm2ddl.auto", "validate");
        
        // Show SQL for debugging (disable in production)
        properties.setProperty("hibernate.show_sql", "true");
        properties.setProperty("hibernate.format_sql", "true");
        
        // Logging
        properties.setProperty("hibernate.use_sql_comments", "true");
        
        // Performance optimizations
        properties.setProperty("hibernate.jdbc.batch_size", "20");
        properties.setProperty("hibernate.jdbc.fetch_size", "50");
        properties.setProperty("hibernate.order_inserts", "true");
        properties.setProperty("hibernate.order_updates", "true");
        properties.setProperty("hibernate.batch_versioned_data", "true");
        
        // Cache settings (if using second-level cache)
        properties.setProperty("hibernate.cache.use_second_level_cache", "false");
        properties.setProperty("hibernate.cache.use_query_cache", "false");
        
        // Physical naming strategy (converts camelCase to snake_case)
        properties.setProperty("hibernate.physical_naming_strategy",
                "org.springframework.boot.orm.jpa.hibernate.SpringPhysicalNamingStrategy");
        
        // Connection handling
        properties.setProperty("hibernate.connection.autocommit", "true");
        properties.setProperty("hibernate.connection.provider_disables_autocommit", "false");
        
        // Statistics (useful for monitoring)
        properties.setProperty("hibernate.generate_statistics", "true");
        
        return properties;
    }
}
