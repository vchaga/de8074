# Hibernate/JPA Configuration for Snowflake with External DataSource

## Overview

This guide shows how to set up Hibernate/JPA with Snowflake when your `SnowflakeDatasource` is provided by an external dependency (library). The solution wraps the external datasource with HikariCP for connection pooling and configures Hibernate for JPA operations.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│        Application Layer (Controllers/Services)         │
└────────────────────────┬────────────────────────────────┘
                         │
                         ↓
┌─────────────────────────────────────────────────────────┐
│         JPA/Hibernate EntityManager                     │
│  - Entity mapping                                        │
│  - Query generation                                      │
│  - Transaction management                                │
└────────────────────────┬────────────────────────────────┘
                         │
                         ↓
┌─────────────────────────────────────────────────────────┐
│         HikariCP DataSource (Connection Pool)           │
│  - Connection pooling (max 10 connections)               │
│  - Connection validation                                 │
│  - Leak detection                                        │
└────────────────────────┬────────────────────────────────┘
                         │
                         ↓
┌─────────────────────────────────────────────────────────┐
│      External SnowflakeDatasource (from dependency)     │
│  - ADFS Token Management                                 │
│  - EPV/Gaia Credential Retrieval                         │
│  - Proxy Authentication                                  │
└────────────────────────┬────────────────────────────────┘
                         │
                         ↓
┌─────────────────────────────────────────────────────────┐
│              Snowflake Database                         │
└─────────────────────────────────────────────────────────┘
```

## Files Included

### Configuration Files
1. **SnowflakeHibernateConfiguration.java** - Main Hibernate/JPA configuration
2. **SnowflakeDialect.java** - Custom Hibernate dialect for Snowflake
3. **SnowflakeDbConfigProperties.java** - Configuration properties

### Entity and Repository
4. **RlenMetadata.java** - Example JPA entity
5. **RlenMetadataRepository.java** - Spring Data JPA repository
6. **RlenDataFetcherService.java** - Service layer with transactions

### Configuration Files
7. **application-hibernate.yml** - Complete application configuration
8. **pom.xml** - Maven dependencies

## Step-by-Step Implementation

### Step 1: Add Dependencies

Add to your `pom.xml`:

```xml
<dependencies>
    <!-- Spring Boot Data JPA -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>

    <!-- Snowflake JDBC Driver -->
    <dependency>
        <groupId>net.snowflake</groupId>
        <artifactId>snowflake-jdbc</artifactId>
        <version>3.14.5</version>
    </dependency>

    <!-- HikariCP -->
    <dependency>
        <groupId>com.zaxxer</groupId>
        <artifactId>HikariCP</artifactId>
        <version>5.1.0</version>
    </dependency>

    <!-- YOUR EXTERNAL LIBRARY with SnowflakeDatasource -->
    <dependency>
        <groupId>com.your.company</groupId>
        <artifactId>snowflake-datasource-library</artifactId>
        <version>1.0.0</version>
    </dependency>
</dependencies>
```

### Step 2: Configure Hibernate Properties

Update `application.yml`:

```yaml
snowflake:
  datasource:
    jdbc-url: jdbc:snowflake://your-account.snowflakecomputing.com/
    username: ${SNOWFLAKE_USERNAME}
    password: ${SNOWFLAKE_PASSWORD}
    maximum-pool-size: 10
    minimum-idle: 2

spring:
  jpa:
    hibernate:
      ddl-auto: validate  # IMPORTANT: Use 'validate' or 'none' for Snowflake
    properties:
      hibernate:
        dialect: com.jpmorgan.ct.config.SnowflakeDialect
        show_sql: true
        format_sql: true
```

### Step 3: Add Configuration Class

The `SnowflakeHibernateConfiguration.java` creates three beans:

1. **hikariSnowflakeDataSource** - HikariCP-wrapped datasource
2. **snowflakeEntityManagerFactory** - Hibernate EntityManagerFactory
3. **snowflakeTransactionManager** - JPA Transaction Manager

Key points:
```java
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    basePackages = "com.jpmorgan.ct.snowflakejpa.repository",
    entityManagerFactoryRef = "snowflakeEntityManagerFactory",
    transactionManagerRef = "snowflakeTransactionManager"
)
public class SnowflakeHibernateConfiguration {
    // Injects the external SnowflakeDatasource
    private final SnowflakeDatasource externalSnowflakeDatasource;
    
    @Bean
    public HikariDataSource hikariSnowflakeDataSource() {
        // Wraps external datasource with HikariCP
    }
    
    @Bean
    public LocalContainerEntityManagerFactoryBean snowflakeEntityManagerFactory() {
        // Configures Hibernate
    }
    
    @Bean
    public PlatformTransactionManager snowflakeTransactionManager() {
        // Configures JPA transactions
    }
}
```

### Step 4: Create JPA Entities

Map your Snowflake tables to JPA entities:

```java
@Entity
@Table(name = "RLEN_METADATA", schema = "YOUR_SCHEMA")
public class RlenMetadata {
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rlen_metadata_seq")
    @SequenceGenerator(name = "rlen_metadata_seq", sequenceName = "RLEN_METADATA_SEQ")
    private Long id;
    
    @Column(name = "RUN_ID")
    private String runId;
    
    // ... other fields
}
```

**Important Entity Mapping Notes:**

1. **Use sequences for ID generation** (Snowflake doesn't support AUTO)
2. **Specify exact table/column names** (Snowflake is case-sensitive when quoted)
3. **Map data types correctly**:
   - `NUMBER(p,s)` → `BigDecimal`
   - `VARCHAR(n)` → `String`
   - `TIMESTAMP_NTZ` → `LocalDateTime`
   - `DATE` → `LocalDate`
   - `BOOLEAN` → `Boolean`
   - `VARIANT` → `String` (JSON as text)

### Step 5: Create Repositories

Spring Data JPA repositories work automatically:

```java
@Repository
public interface RlenMetadataRepository extends JpaRepository<RlenMetadata, Long> {
    
    // Query methods - auto-implemented by Spring
    Optional<RlenMetadata> findByRunIdAndLeIdAndCobDateAndConsolidationCode(
        String runId, String leId, LocalDate cobDate, String consolidationCode
    );
    
    // Native Snowflake SQL
    @Query(value = "SELECT * FROM RLEN_METADATA WHERE RUN_ID = :runId", 
           nativeQuery = true)
    List<RlenMetadata> findByRunIdNative(@Param("runId") String runId);
}
```

### Step 6: Use in Service Layer

```java
@Service
public class RlenDataFetcherService {
    
    private final RlenMetadataRepository repository;
    
    @Transactional(value = "snowflakeTransactionManager", readOnly = true)
    public ValidationResponse runRlenDataValidation(
            String runId, String leId, String cobDate, String consolidationCode) {
        
        Optional<RlenMetadata> metadata = repository
            .findByRunIdAndLeIdAndCobDateAndConsolidationCode(
                runId, leId, LocalDate.parse(cobDate), consolidationCode
            );
        
        return metadata.isPresent() 
            ? new ValidationResponse(true, "Run Id Found", metadata.get())
            : new ValidationResponse(false, "Run Id Not Found", null);
    }
    
    @Transactional(value = "snowflakeTransactionManager")
    public RlenMetadata saveMetadata(RlenMetadata metadata) {
        return repository.save(metadata);
    }
}
```

## How It Works

### Connection Flow

1. **Service calls repository** method
2. **Repository uses EntityManager** to generate SQL
3. **EntityManager requests connection** from HikariCP
4. **HikariCP checks pool** for available connection
5. If no connection available:
   - **Calls external SnowflakeDatasource.getConnection()**
   - External datasource handles ADFS token refresh
   - External datasource retrieves password from EPV/Gaia
   - Connection is created and added to pool
6. **Query executes** on Snowflake
7. **Connection returns to pool** (not closed)

### Transaction Management

```java
@Transactional(value = "snowflakeTransactionManager")
public void updateData() {
    // All operations in this method use same connection
    repository.save(entity1);
    repository.save(entity2);
    // Commits automatically if no exception
    // Rolls back if exception thrown
}
```

## Important Snowflake-Specific Considerations

### 1. DDL Auto Configuration

**CRITICAL**: Set `hibernate.hbm2ddl.auto` correctly:

```yaml
spring:
  jpa:
    hibernate:
      ddl-auto: validate  # Recommended for production
      # ddl-auto: none    # Alternative for production
      # NEVER use: create, create-drop, or update
```

**Why?** Snowflake has limitations:
- No support for some DDL operations Hibernate might attempt
- Schema changes should be managed via migrations (Flyway/Liquibase)
- Auto-generation can create incorrect schemas

### 2. Hibernate Dialect

Use the custom `SnowflakeDialect` provided, or fall back to PostgreSQL:

```yaml
spring:
  jpa:
    properties:
      hibernate:
        dialect: com.jpmorgan.ct.config.SnowflakeDialect
```

The custom dialect provides:
- Snowflake-specific function mappings
- Correct data type handling
- Sequence support
- Case-sensitivity handling

### 3. ID Generation Strategy

Always use sequences:

```java
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq")
@SequenceGenerator(name = "my_seq", sequenceName = "MY_TABLE_SEQ", allocationSize = 1)
private Long id;
```

**Don't use**:
- `GenerationType.AUTO`
- `GenerationType.IDENTITY`

### 4. Case Sensitivity

Snowflake stores unquoted identifiers in UPPERCASE:

```java
// This will look for TABLE_NAME, not table_name
@Table(name = "TABLE_NAME")

// To preserve case, quote it
@Table(name = "\"table_name\"")
```

### 5. Unsupported Features

Snowflake doesn't support:
- `SELECT ... FOR UPDATE` (locks)
- Some constraint types
- Certain DDL operations

Use native queries for Snowflake-specific operations:

```java
@Query(value = "SELECT * FROM table WHERE date >= DATEADD(day, -30, CURRENT_DATE())", 
       nativeQuery = true)
List<Entity> findRecent();
```

## Testing

### Unit Testing with H2

```java
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class RepositoryTest {
    
    @Autowired
    private RlenMetadataRepository repository;
    
    @Test
    void testFindByRunId() {
        RlenMetadata metadata = new RlenMetadata();
        metadata.setRunId("TEST123");
        repository.save(metadata);
        
        List<RlenMetadata> found = repository.findByRunId("TEST123");
        assertEquals(1, found.size());
    }
}
```

### Integration Testing

```java
@SpringBootTest
@Transactional
class ServiceIntegrationTest {
    
    @Autowired
    private RlenDataFetcherService service;
    
    @Test
    void testValidation() {
        ValidationResponse response = service.runRlenDataValidation(
            "RUN001", "LE001", "2024-01-01", "CODE001"
        );
        
        assertNotNull(response);
    }
}
```

## Monitoring

### HikariCP Metrics

Access via actuator:
```
http://localhost:8080/actuator/metrics/hikaricp.connections.active
http://localhost:8080/actuator/metrics/hikaricp.connections.idle
```

### Hibernate Statistics

Enable in configuration:
```yaml
spring:
  jpa:
    properties:
      hibernate:
        generate_statistics: true
```

Access programmatically:
```java
Statistics stats = entityManager.unwrap(Session.class)
    .getSessionFactory()
    .getStatistics();
```

## Troubleshooting

### Issue: "Table not found"

**Cause**: Case sensitivity mismatch

**Solution**:
```java
// Use uppercase
@Table(name = "MY_TABLE")

// Or verify actual case in Snowflake
SHOW TABLES LIKE '%my_table%';
```

### Issue: "Sequence does not exist"

**Cause**: Sequence not created in Snowflake

**Solution**:
```sql
CREATE SEQUENCE MY_TABLE_SEQ START = 1 INCREMENT = 1;
```

### Issue: "Cannot use GenerationType.IDENTITY"

**Cause**: Snowflake doesn't support MySQL-style auto-increment

**Solution**: Use sequences (see above)

### Issue: Slow queries

**Cause**: No connection pooling or wrong pool settings

**Solution**:
```yaml
snowflake:
  datasource:
    maximum-pool-size: 20  # Increase pool size
    connection-timeout: 60000  # Increase timeout
```

### Issue: Connection leaks

**Cause**: Not using try-with-resources or @Transactional

**Solution**:
```java
// Always use @Transactional
@Transactional
public void myMethod() {
    // Repository operations
}

// Or try-with-resources for manual connection management
try (Connection conn = dataSource.getConnection()) {
    // Use connection
}
```

## Migration from JDBC to JPA

If you have existing JDBC code:

### Before (JDBC):
```java
try (Connection conn = snowflakeDatasource.getConnection()) {
    PreparedStatement stmt = conn.prepareStatement(
        "SELECT * FROM RLEN_METADATA WHERE RUN_ID = ?"
    );
    stmt.setString(1, runId);
    ResultSet rs = stmt.executeQuery();
    // Process results...
}
```

### After (JPA):
```java
@Transactional(readOnly = true)
public List<RlenMetadata> findByRunId(String runId) {
    return repository.findByRunId(runId);
}
```

## Best Practices

1. **Always use @Transactional** for database operations
2. **Set `readOnly = true`** for read-only transactions
3. **Use sequences** for ID generation
4. **Validate schema** instead of auto-generating
5. **Quote identifiers** if using lowercase/mixed case
6. **Use native queries** for Snowflake-specific features
7. **Monitor connection pool** metrics
8. **Test with actual Snowflake** (not H2) for integration tests
9. **Set appropriate timeouts** for long-running queries
10. **Use batch operations** for bulk inserts/updates

## Performance Tips

1. **Batch Processing**:
```java
@Transactional
public void batchInsert(List<RlenMetadata> entities) {
    int batchSize = 20;
    for (int i = 0; i < entities.size(); i++) {
        repository.save(entities.get(i));
        if (i % batchSize == 0) {
            entityManager.flush();
            entityManager.clear();
        }
    }
}
```

2. **Query Optimization**:
```java
// Use projection for large result sets
interface MetadataProjection {
    String getRunId();
    LocalDate getCobDate();
}

List<MetadataProjection> findByIsActiveTrue();
```

3. **Connection Pool Tuning**:
```yaml
snowflake:
  datasource:
    maximum-pool-size: 20      # Based on load
    minimum-idle: 5            # Keep connections warm
    idle-timeout: 300000       # 5 minutes
    max-lifetime: 1800000      # 30 minutes
```

## Additional Resources

- [Hibernate Documentation](https://hibernate.org/orm/documentation/)
- [Spring Data JPA Reference](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/)
- [Snowflake JDBC Driver](https://docs.snowflake.com/en/user-guide/jdbc)
- [HikariCP GitHub](https://github.com/brettwooldridge/HikariCP)

## Summary

This setup provides:
✅ Full JPA/Hibernate support with Snowflake  
✅ Connection pooling via HikariCP  
✅ Integration with external SnowflakeDatasource  
✅ ADFS token management  
✅ EPV/Gaia credential support  
✅ Transaction management  
✅ Spring Data JPA repositories  
✅ Monitoring and metrics  

The key is that your external `SnowflakeDatasource` handles authentication and token management, while HikariCP provides connection pooling, and Hibernate provides the ORM layer.
